
            <div class="mt-8 leading-normal text-xs text-gray-500 space-y-1">
                <p class="text-center">
                    <a class="link-default" href="/">Jimmy Jradeh</a> · {{date("Y")}}
                </p>
            </div>
            