
                <div class="mt-8 leading-normal text-xs text-gray-500 space-y-1">
                    <p class="text-center">
                        <a class="link-default" href="/">Jimmy Jradeh</a> · <?php echo e(date("Y")); ?>

                    </p>
                </div>
            <?php /**PATH C:\Users\jimmy\OneDrive\Desktop\Work\Personal\portfolio\storage\framework\views/5344f40ec0ad4a81a551288dcb8a98a5.blade.php ENDPATH**/ ?>