
            <div class="mt-8 leading-normal text-xs text-gray-500 space-y-1">
                <p class="text-center">
                    <a class="link-default" href="/">Jimmy Jradeh</a> · <?php echo e(date("Y")); ?>

                </p>
            </div>
            <?php /**PATH C:\Users\jimmy\OneDrive\Desktop\portfolio\storage\framework\views/fdd58f8acbf94b2c9608bfdd75dd5742.blade.php ENDPATH**/ ?>