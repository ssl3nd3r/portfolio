
            <div class="mt-8 leading-normal text-xs text-gray-500 space-y-1">
                <p class="text-center">
                    Powered by <a class="link-default" href="/">Jimmy Jradeh</a> · <?php echo e(date("y")); ?>

                </p>
            </div>
            <?php /**PATH C:\Users\jimmy\OneDrive\Desktop\portfolio\storage\framework\views/ef0524845d3d25e32f5c6b8fa909bd2a.blade.php ENDPATH**/ ?>