
            <div class="mt-8 leading-normal text-xs text-gray-500 space-y-1">
                <p class="text-center">
                    Powered by <a class="link-default" href="/">Jimmy Jradeh</a> · <?php echo e(time()->year); ?>

                </p>
            </div>
            <?php /**PATH C:\Users\jimmy\OneDrive\Desktop\portfolio\storage\framework\views/5f9bb616bd2cad5af1baff102b253a3b.blade.php ENDPATH**/ ?>