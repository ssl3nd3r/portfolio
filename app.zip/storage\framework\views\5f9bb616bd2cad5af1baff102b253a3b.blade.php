
            <div class="mt-8 leading-normal text-xs text-gray-500 space-y-1">
                <p class="text-center">
                    Powered by <a class="link-default" href="/">Jimmy Jradeh</a> · {{time()->year}}
                </p>
            </div>
            